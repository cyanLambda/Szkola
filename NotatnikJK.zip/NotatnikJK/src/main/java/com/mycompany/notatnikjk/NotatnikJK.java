/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.notatnikjk;

/**
 *
 * @author Cyan_Lambda
 */
public class NotatnikJK {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
