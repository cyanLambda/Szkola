/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.notatnik;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class NotesDBLoadSave {
    // Connect to DB
    public static Connection connectDB() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/Notes",
                    "root", "");

            return con;
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
    //    ----------------------SAVE-------------------------
    public static void saveToDB(String fileName, String fileContent) {
        Connection con = null;
        PreparedStatement ps = null;

        con = connectDB();

        if(fileName == null){
            return;
        }
            
        try {
            String sql = "INSERT INTO savedFiles (fileName, content) VALUES (?, ?)";

            ps = con.prepareStatement(sql);
            ps.setString(1, fileName);
            ps.setString(2, fileContent);

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    //   -------------------------LOAD--------------------------------
    public static String loadFromDB(String fileName) {
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
     
    con = connectDB();

    try {
        String sql = "SELECT content FROM savedFiles WHERE fileName = ?";
        
        ps = con.prepareStatement(sql);
        ps.setString(1, fileName);

        rs = ps.executeQuery();

        if(rs.next()){
            String fileContent = rs.getString("content");
            return fileContent;
        }else{
            return "File not found in the database.";
        }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return "Error";
    }
}
